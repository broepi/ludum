#!/bin/sh
export LD_LIBRARY_PATH=libs:LD_LIBRARY_PATH
./binary
